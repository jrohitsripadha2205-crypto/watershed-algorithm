"""
gui.py
======
Main window for the Additive Manufacturing (AM) Defect Detection
application.

Built with CustomTkinter + Tkinter (PyQt5 has been fully removed).

Layout
------
* Left panel: scrollable control panel with grouped parameter sliders
  (Preprocessing, Gradient, Markers, Watershed, Region Analysis, Overlay).
  Every parameter change re-runs the pipeline and refreshes every tab.
* Center: a CTkTabview with one tab per pipeline stage:
    1. Original Image
    2. DoG
    3. Gaussian Division
    4. Preprocessing
    5. Gradient / Topographic Surface
    6. Marker Generation
    7. Watershed Segmentation
    8. Region Analysis
    9. Overlay on Original Image
    10. Batch Processing
"""

from __future__ import annotations

import os
import sys
import traceback

import numpy as np
import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from widgets import ParamControl, CheckBox, ComboBox, GroupBox
import pipeline as pl
import batch as bt


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


# ---------------------------------------------------------------------------
# A single matplotlib canvas wrapped for easy embedding inside a tab
# ---------------------------------------------------------------------------

class ImageTab(ctk.CTkFrame):
    """A tab that shows a single image (grayscale or RGB) with a title."""

    def __init__(self, master, title: str, cmap: str = "gray"):
        super().__init__(master, fg_color="transparent")
        self.title = title
        self.cmap = cmap

        self.figure = Figure(figsize=(5, 4), tight_layout=True)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_axis_off()

        self.info_label = ctk.CTkLabel(
            self, text="", text_color="#999999", font=("", 11), anchor="w"
        )

        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        self.info_label.pack(fill="x", padx=4, pady=(0, 4))

    def show_image(self, img: np.ndarray | None, info: str = "", cmap: str | None = None):
        self.ax.clear()
        self.ax.set_axis_off()
        if img is None:
            self.info_label.configure(text=info)
            self.canvas.draw_idle()
            return
        use_cmap = cmap if cmap is not None else (None if img.ndim == 3 else self.cmap)
        self.ax.imshow(img, cmap=use_cmap)
        self.ax.set_title(self.title, fontsize=10)
        self.info_label.configure(text=info)
        self.canvas.draw_idle()


class MarkerTab(ctk.CTkFrame):
    """Special tab for marker visualization: overlays dark/bright/background
    seed points on top of the smoothed image."""

    def __init__(self, master):
        super().__init__(master, fg_color="transparent")
        self.figure = Figure(figsize=(5, 4), tight_layout=True)
        self.canvas = FigureCanvasTkAgg(self.figure, master=self)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_axis_off()
        self.info_label = ctk.CTkLabel(
            self, text="", text_color="#999999", font=("", 11), anchor="w"
        )
        self.canvas.get_tk_widget().pack(fill="both", expand=True)
        self.info_label.pack(fill="x", padx=4, pady=(0, 4))

    def show_markers(self, smoothed: np.ndarray, marker_result: "pl.MarkerResult", info: str = ""):
        self.ax.clear()
        self.ax.set_axis_off()
        self.ax.imshow(smoothed, cmap="gray")
        ys, xs = np.nonzero(marker_result.dark_mask)
        self.ax.scatter(xs, ys, s=14, c="deepskyblue", marker="o", label="dark-defect seed")
        ys, xs = np.nonzero(marker_result.bright_mask)
        self.ax.scatter(xs, ys, s=14, c="red", marker="o", label="bright-defect seed")
        ys, xs = np.nonzero(marker_result.background_mask)
        self.ax.scatter(xs, ys, s=4, c="lime", marker=".", alpha=0.5, label="background seed")
        self.ax.set_title("Marker Generation (extrema-based seeds)", fontsize=10)
        self.ax.legend(loc="upper right", fontsize=7, framealpha=0.6)
        self.info_label.configure(text=info)
        self.canvas.draw_idle()


class RegionAnalysisTab(ctk.CTkFrame):
    """Table view of regionprops-derived measurements."""

    _COLUMNS = (
        "label", "role", "area", "mean_intensity", "eccentricity",
        "perimeter", "equiv_diameter", "solidity",
    )
    _HEADINGS = (
        "Label", "Role", "Area (px)", "Mean Intensity", "Eccentricity",
        "Perimeter", "Equiv. Diameter", "Solidity",
    )

    def __init__(self, master):
        super().__init__(master, fg_color="transparent")

        self.summary_label = ctk.CTkLabel(
            self, text="", font=ctk.CTkFont(weight="bold"), anchor="w"
        )
        self.summary_label.pack(fill="x", padx=4, pady=4)

        table_frame = ctk.CTkFrame(self, fg_color="transparent")
        table_frame.pack(fill="both", expand=True, padx=4, pady=(0, 4))

        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(
            "Regions.Treeview", background="#2b2b2b", fieldbackground="#2b2b2b",
            foreground="#e0e0e0", rowheight=24,
        )
        style.configure(
            "Regions.Treeview.Heading", background="#3a3a3a", foreground="#f0f0f0",
        )
        style.map("Regions.Treeview", background=[("selected", "#1f6aa5")])

        self.table = ttk.Treeview(
            table_frame, columns=self._COLUMNS, show="headings",
            style="Regions.Treeview",
        )
        for col, heading in zip(self._COLUMNS, self._HEADINGS):
            self.table.heading(col, text=heading)
            self.table.column(col, width=100, anchor="center", stretch=True)

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=vsb.set)
        self.table.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        self.table.tag_configure("defect", background="#4a2020")
        self.table.tag_configure("background", background="#204a20")
        self.table.tag_configure("noise", background="#3a3a3a")

    def show_regions(self, region_result: "pl.RegionAnalysisResult"):
        rows = region_result.table
        for item in self.table.get_children():
            self.table.delete(item)

        n_defects = sum(1 for r in rows if r["role"] == "defect")
        n_noise = sum(1 for r in rows if r["role"] == "noise")
        self.summary_label.configure(
            text=(
                f"{len(rows)} total regions   |   {n_defects} defects   |   "
                f"{n_noise} filtered as noise   |   1 background region"
            )
        )

        for r in rows:
            values = (
                str(r["label"]), r["role"], str(r["area"]),
                f"{r['mean_intensity']:.4f}", f"{r['eccentricity']:.3f}",
                f"{r['perimeter']:.1f}", f"{r['equivalent_diameter']:.2f}",
                f"{r['solidity']:.3f}",
            )
            tag = r["role"] if r["role"] in ("defect", "background", "noise") else ""
            self.table.insert("", "end", values=values, tags=(tag,))


class BatchTab(ctk.CTkFrame):
    """
    Batch Processing tab: pick an input folder and an output folder, run
    the existing single-image pipeline (via batch.BatchWorker) over every
    supported image in the input folder, and save every output the
    application already generates into one subfolder per input image.
    """

    def __init__(self, master, get_params_callback):
        super().__init__(master, fg_color="transparent")
        self._get_params = get_params_callback
        self.input_folder = ""
        self.output_folder = ""
        self.worker: bt.BatchWorker | None = None

        folders_box = GroupBox(self, "Folders")
        folders_box.pack(fill="x", padx=4, pady=4)

        row0 = ctk.CTkFrame(folders_box.content, fg_color="transparent")
        row0.pack(fill="x", pady=2)
        ctk.CTkLabel(row0, text="Input Folder:", width=110, anchor="w").pack(side="left")
        self.input_label = ctk.CTkLabel(row0, text="(none selected)", text_color="#999999", anchor="w")
        self.input_label.pack(side="left", fill="x", expand=True, padx=6)
        self.input_btn = ctk.CTkButton(row0, text="Select Input Folder…", command=self._select_input_folder)
        self.input_btn.pack(side="left")

        row1 = ctk.CTkFrame(folders_box.content, fg_color="transparent")
        row1.pack(fill="x", pady=2)
        ctk.CTkLabel(row1, text="Output Folder:", width=110, anchor="w").pack(side="left")
        self.output_label = ctk.CTkLabel(row1, text="(none selected)", text_color="#999999", anchor="w")
        self.output_label.pack(side="left", fill="x", expand=True, padx=6)
        self.output_btn = ctk.CTkButton(row1, text="Select Output Folder…", command=self._select_output_folder)
        self.output_btn.pack(side="left")

        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(fill="x", padx=4, pady=4)
        self.start_btn = ctk.CTkButton(btn_row, text="Start", command=self._start)
        self.start_btn.pack(side="left", padx=(0, 6))
        self.cancel_btn = ctk.CTkButton(btn_row, text="Cancel", command=self._cancel, state="disabled")
        self.cancel_btn.pack(side="left")

        progress_box = GroupBox(self, "Progress")
        progress_box.pack(fill="x", padx=4, pady=4)
        self.progress_bar = ctk.CTkProgressBar(progress_box.content)
        self.progress_bar.set(0)
        progress_box.add(self.progress_bar)
        self.current_file_label = ctk.CTkLabel(progress_box.content, text="Current file: —", anchor="w")
        progress_box.add(self.current_file_label)
        self.processed_count_label = ctk.CTkLabel(progress_box.content, text="Processed: 0 / 0", anchor="w")
        progress_box.add(self.processed_count_label)

        self.summary_label = ctk.CTkLabel(
            self, text="", font=ctk.CTkFont(weight="bold"), anchor="w", wraplength=700, justify="left"
        )
        self.summary_label.pack(fill="x", padx=4, pady=4)

        ctk.CTkLabel(self, text="Errors / Log:", anchor="w").pack(fill="x", padx=4)
        log_frame = ctk.CTkFrame(self, fg_color="transparent")
        log_frame.pack(fill="both", expand=True, padx=4, pady=(0, 4))
        self.log_list = tk.Listbox(
            log_frame, background="#2b2b2b", foreground="#e0e0e0",
            selectbackground="#1f6aa5", borderwidth=0, highlightthickness=0,
        )
        log_vsb = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_list.yview)
        self.log_list.configure(yscrollcommand=log_vsb.set)
        self.log_list.pack(side="left", fill="both", expand=True)
        log_vsb.pack(side="right", fill="y")

        # so worker-thread callbacks can be marshalled back to the Tk main
        # loop via `self.after(0, ...)`.
        self._num_pending_cancel = False

    # -- folder selection -------------------------------------------------

    def _select_input_folder(self):
        path = filedialog.askdirectory(title="Select Input Folder")
        if path:
            self.input_folder = path
            self.input_label.configure(text=path)

    def _select_output_folder(self):
        path = filedialog.askdirectory(title="Select Output Folder")
        if path:
            self.output_folder = path
            self.output_label.configure(text=path)

    # -- run control --------------------------------------------------

    def _start(self):
        if not self.input_folder or not os.path.isdir(self.input_folder):
            messagebox.showwarning("Batch Processing", "Please select a valid input folder.")
            return
        if not self.output_folder:
            messagebox.showwarning("Batch Processing", "Please select an output folder.")
            return

        files = bt.list_supported_images(self.input_folder)
        if not files:
            messagebox.showinfo(
                "Batch Processing",
                "No supported images (png, jpg, jpeg, bmp, tif, tiff) found in the input folder."
            )
            return

        self.log_list.delete(0, "end")
        self.summary_label.configure(text="")
        self._total_files = len(files)
        self.progress_bar.set(0)
        self.current_file_label.configure(text="Current file: —")
        self.processed_count_label.configure(text=f"Processed: 0 / {len(files)}")

        self.start_btn.configure(state="disabled")
        self.input_btn.configure(state="disabled")
        self.output_btn.configure(state="disabled")
        self.cancel_btn.configure(state="normal")

        params = self._get_params()
        self.worker = bt.BatchWorker(
            self.input_folder, self.output_folder, params,
            on_progress=lambda p, t: self.after(0, self._on_progress, p, t),
            on_current_file=lambda f: self.after(0, self._on_current_file, f),
            on_image_failed=lambda f, m: self.after(0, self._on_image_failed, f, m),
            on_finished=lambda t, s, f: self.after(0, self._on_finished, t, s, f),
        )
        self.worker.start()

    def _cancel(self):
        if self.worker is not None:
            self.cancel_btn.configure(state="disabled")
            self.current_file_label.configure(text="Current file: cancelling…")
            self.worker.cancel()

    # -- worker callback handlers (run on the Tk main thread) --------------

    def _on_progress(self, processed: int, total: int):
        self.progress_bar.set(processed / total if total else 0)
        self.processed_count_label.configure(text=f"Processed: {processed} / {total}")

    def _on_current_file(self, filename: str):
        self.current_file_label.configure(text=f"Current file: {filename}")

    def _on_image_failed(self, filename: str, message: str):
        first_line = message.splitlines()[0] if message else "Unknown error"
        self.log_list.insert("end", f"FAILED: {filename} — {first_line}")

    def _on_finished(self, total: int, succeeded: int, failed: int):
        self.start_btn.configure(state="normal")
        self.input_btn.configure(state="normal")
        self.output_btn.configure(state="normal")
        self.cancel_btn.configure(state="disabled")
        self.current_file_label.configure(text="Current file: —")

        if self.worker is not None and self.worker._cancel_requested and (succeeded + failed) < total:
            self.summary_label.configure(
                text=(
                    f"Cancelled — {succeeded + failed} / {total} processed "
                    f"({succeeded} succeeded, {failed} failed) before stopping."
                )
            )
        else:
            self.summary_label.configure(
                text=(
                    f"Completed — {succeeded} / {total} succeeded, {failed} failed. "
                    f"Output saved to: {self.output_folder}"
                )
            )
        self.worker = None


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------

class MainWindow(ctk.CTk):
    _DOG_DEFAULT_SIGMA1 = 1.0
    _DOG_DEFAULT_SIGMA2 = 2.0
    _GDIV_DEFAULT_SIGMA = 5.0
    _GDIV_DEFAULT_EPSILON = 1e-4

    def __init__(self):
        super().__init__()
        self.title("AM Defect Detection — Watershed Segmentation")
        self.geometry("1400x900")

        self.rgb = None
        self.gray = None
        self._last_result: pl.PipelineResult | None = None

        # Debounce timer so rapid slider drags don't queue up redundant
        # full-pipeline recomputations; still feels "live" (~60ms).
        self._recompute_after_id = None

        self._build_ui()

    # -- UI construction ---------------------------------------------------

    def _build_ui(self):
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        left = self._build_control_panel()
        left.grid(row=0, column=0, sticky="nsw", padx=(6, 3), pady=6)

        right = self._build_tabs()
        right.grid(row=0, column=1, sticky="nsew", padx=(3, 6), pady=6)

        self.status_label = ctk.CTkLabel(self, text="Load an image to begin.", anchor="w")
        self.status_label.grid(row=1, column=0, columnspan=2, sticky="ew", padx=8, pady=(0, 4))

    def statusBar_showMessage(self, message: str):
        self.status_label.configure(text=message)

    def _build_control_panel(self) -> ctk.CTkFrame:
        panel = ctk.CTkFrame(self, width=340)
        panel.grid_propagate(False)

        # -- Load / Save buttons --
        io_box = GroupBox(panel, "Image")
        io_box.pack(fill="x", padx=4, pady=(4, 4))
        self.load_btn = ctk.CTkButton(io_box.content, text="Load Image…", command=self.on_load_image)
        io_box.add(self.load_btn)
        self.save_btn = ctk.CTkButton(
            io_box.content, text="Save Overlay As…", command=self.on_save_overlay, state="disabled"
        )
        io_box.add(self.save_btn)

        scroll = ctk.CTkScrollableFrame(panel, width=320)
        scroll.pack(fill="both", expand=True, padx=4, pady=(0, 4))

        scroll.add = lambda w, **kw: w.pack(in_=scroll, fill="x", pady=4)  # convenience, unused externally

        self._build_dog_group(scroll)
        self._build_gdiv_group(scroll)
        self._build_preprocessing_group(scroll)
        self._build_gradient_group(scroll)
        self._build_marker_group(scroll)
        self._build_watershed_group(scroll)
        self._build_region_group(scroll)
        self._build_overlay_group(scroll)

        return panel

    # -- Parameter groups ---------------------------------------------------

    # -- Optional Gaussian preprocessing (Task 1) ---------------------------

    def _build_dog_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "1. Difference of Gaussian (DoG) — optional")
        box.pack(fill="x", pady=4)

        self.dog_enabled_checkbox = CheckBox(box.content, text="Enable DoG preprocessing")
        self.dog_enabled_checkbox.stateChanged.connect(self._on_dog_toggled)
        box.add(self.dog_enabled_checkbox)

        self.dog_sigma1_ctrl = ParamControl(
            "Sigma 1", 0.1, 20.0, self._DOG_DEFAULT_SIGMA1, step=0.1, decimals=1,
            tooltip="Standard deviation of the first Gaussian blur (typically the "
                    "smaller of the two).",
            master=box.content,
        )
        self.dog_sigma2_ctrl = ParamControl(
            "Sigma 2", 0.1, 30.0, self._DOG_DEFAULT_SIGMA2, step=0.1, decimals=1,
            tooltip="Standard deviation of the second Gaussian blur (typically the "
                    "larger of the two). DoG = Gaussian(I, sigma1) - Gaussian(I, sigma2).",
            master=box.content,
        )
        for c in (self.dog_sigma1_ctrl, self.dog_sigma2_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            c.setEnabled(False)
            box.add(c)

        self.dog_reset_btn = ctk.CTkButton(box.content, text="Reset to Defaults", command=self._reset_dog)
        box.add(self.dog_reset_btn)

        return box

    def _on_dog_toggled(self, _state):
        enabled = self.dog_enabled_checkbox.isChecked()
        self.dog_sigma1_ctrl.setEnabled(enabled)
        self.dog_sigma2_ctrl.setEnabled(enabled)
        self._schedule_recompute()

    def _reset_dog(self):
        self.dog_sigma1_ctrl.setValue(self._DOG_DEFAULT_SIGMA1)
        self.dog_sigma2_ctrl.setValue(self._DOG_DEFAULT_SIGMA2)
        self.dog_enabled_checkbox.setChecked(False)
        self.dog_sigma1_ctrl.setEnabled(False)
        self.dog_sigma2_ctrl.setEnabled(False)
        self._schedule_recompute()

    def _build_gdiv_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "2. Gaussian Division — optional")
        box.pack(fill="x", pady=4)

        self.gdiv_enabled_checkbox = CheckBox(box.content, text="Enable Gaussian Division")
        self.gdiv_enabled_checkbox.stateChanged.connect(self._on_gdiv_toggled)
        box.add(self.gdiv_enabled_checkbox)

        self.gdiv_sigma_ctrl = ParamControl(
            "Sigma", 0.5, 50.0, self._GDIV_DEFAULT_SIGMA, step=0.5, decimals=1,
            tooltip="Standard deviation of the Gaussian used to estimate the local "
                    "illumination background. Output = I / (Gaussian(I, sigma) + epsilon).",
            master=box.content,
        )
        self.gdiv_epsilon_ctrl = ParamControl(
            "Epsilon", 0.0001, 0.1, self._GDIV_DEFAULT_EPSILON, step=0.0001, decimals=4,
            tooltip="Small constant added to the denominator to avoid division by zero.",
            master=box.content,
        )
        for c in (self.gdiv_sigma_ctrl, self.gdiv_epsilon_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            c.setEnabled(False)
            box.add(c)

        self.gdiv_reset_btn = ctk.CTkButton(box.content, text="Reset to Defaults", command=self._reset_gdiv)
        box.add(self.gdiv_reset_btn)

        return box

    def _on_gdiv_toggled(self, _state):
        enabled = self.gdiv_enabled_checkbox.isChecked()
        self.gdiv_sigma_ctrl.setEnabled(enabled)
        self.gdiv_epsilon_ctrl.setEnabled(enabled)
        self._schedule_recompute()

    def _reset_gdiv(self):
        self.gdiv_sigma_ctrl.setValue(self._GDIV_DEFAULT_SIGMA)
        self.gdiv_epsilon_ctrl.setValue(self._GDIV_DEFAULT_EPSILON)
        self.gdiv_enabled_checkbox.setChecked(False)
        self.gdiv_sigma_ctrl.setEnabled(False)
        self.gdiv_epsilon_ctrl.setEnabled(False)
        self._schedule_recompute()

    def _build_preprocessing_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "3. Preprocessing (denoise)")
        box.pack(fill="x", pady=4)

        box.add(ctk.CTkLabel(box.content, text="Method", anchor="w"))
        self.pre_method_combo = ComboBox(box.content)
        self.pre_method_combo.addItems(["none", "gaussian", "median", "bilateral"])
        self.pre_method_combo.setCurrentText("gaussian")
        self.pre_method_combo.currentTextChanged.connect(self._schedule_recompute)
        box.add(self.pre_method_combo)

        self.gaussian_sigma_ctrl = ParamControl(
            "Gaussian sigma", 0.0, 10.0, 1.0, step=0.1, decimals=1,
            tooltip="Standard deviation of the Gaussian smoothing kernel.",
            master=box.content,
        )
        self.median_radius_ctrl = ParamControl(
            "Median disk radius", 1, 15, 2, step=1, decimals=0,
            tooltip="Radius of the disk structuring element for median filtering.",
            master=box.content,
        )
        self.bilateral_sigma_color_ctrl = ParamControl(
            "Bilateral sigma (color)", 0.01, 1.0, 0.05, step=0.01, decimals=2,
            master=box.content,
        )
        self.bilateral_sigma_spatial_ctrl = ParamControl(
            "Bilateral sigma (spatial)", 0.5, 20.0, 5.0, step=0.5, decimals=1,
            master=box.content,
        )

        for c in (self.gaussian_sigma_ctrl, self.median_radius_ctrl,
                  self.bilateral_sigma_color_ctrl, self.bilateral_sigma_spatial_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            box.add(c)

        return box

    def _build_gradient_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "4. Gradient / Topographic Surface")
        box.pack(fill="x", pady=4)

        box.add(ctk.CTkLabel(box.content, text="Method", anchor="w"))
        self.grad_method_combo = ComboBox(box.content)
        self.grad_method_combo.addItems(["sobel", "scharr", "prewitt", "morphological"])
        self.grad_method_combo.currentTextChanged.connect(self._schedule_recompute)
        box.add(self.grad_method_combo)

        self.grad_presmooth_ctrl = ParamControl(
            "Gradient presmoothing sigma", 0.0, 5.0, 0.0, step=0.1, decimals=1,
            tooltip="Extra Gaussian blur applied to the gradient surface itself, "
                    "useful for merging noisy micro-basins.",
            master=box.content,
        )
        self.grad_morph_radius_ctrl = ParamControl(
            "Morphological gradient radius", 1, 10, 1, step=1, decimals=0,
            tooltip="Structuring-element radius used only when method='morphological'.",
            master=box.content,
        )

        for c in (self.grad_presmooth_ctrl, self.grad_morph_radius_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            box.add(c)

        return box

    def _build_marker_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "5. Marker Generation (extrema-based, no threshold)")
        box.pack(fill="x", pady=4)

        self.h_dark_ctrl = ParamControl(
            "Dark-defect sensitivity (h)", 0.001, 0.5, 0.03, step=0.001, decimals=3,
            tooltip="h-minima persistence depth. Smaller = more sensitive to shallow "
                    "dark defects (also more noise-prone).",
            master=box.content,
        )
        self.h_bright_ctrl = ParamControl(
            "Bright-defect sensitivity (h)", 0.001, 0.5, 0.03, step=0.001, decimals=3,
            tooltip="h-maxima persistence depth for bright defects (spatter, over-melt).",
            master=box.content,
        )
        self.h_background_ctrl = ParamControl(
            "Background flatness (h)", 0.001, 0.5, 0.05, step=0.001, decimals=3,
            tooltip="h-minima persistence depth applied to the gradient surface to "
                    "find flat, defect-free background plateaus.",
            master=box.content,
        )
        self.marker_dilation_ctrl = ParamControl(
            "Marker dilation radius", 0, 10, 0, step=1, decimals=0,
            tooltip="Optional dilation of seed points to make them more robust.",
            master=box.content,
        )

        for c in (self.h_dark_ctrl, self.h_bright_ctrl, self.h_background_ctrl,
                  self.marker_dilation_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            box.add(c)

        box.add(ctk.CTkLabel(box.content, text="Marker connectivity", anchor="w"))
        self.marker_connectivity_combo = ComboBox(box.content)
        self.marker_connectivity_combo.addItems(["1 (4-connected)", "2 (8-connected)"])
        self.marker_connectivity_combo.setCurrentIndex(1)
        self.marker_connectivity_combo.currentIndexChanged.connect(self._schedule_recompute)
        box.add(self.marker_connectivity_combo)

        return box

    def _build_watershed_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "6. Watershed Segmentation")
        box.pack(fill="x", pady=4)

        box.add(ctk.CTkLabel(box.content, text="Watershed connectivity", anchor="w"))
        self.ws_connectivity_combo = ComboBox(box.content)
        self.ws_connectivity_combo.addItems(["1 (4-connected)", "2 (8-connected)"])
        self.ws_connectivity_combo.setCurrentIndex(1)
        self.ws_connectivity_combo.currentIndexChanged.connect(self._schedule_recompute)
        box.add(self.ws_connectivity_combo)

        self.ws_compactness_ctrl = ParamControl(
            "Compactness", 0.0, 1.0, 0.0, step=0.001, decimals=3,
            tooltip="Higher values favor more regularly-shaped (compact) catchment "
                    "basins (compact watershed).",
            master=box.content,
        )
        self.ws_compactness_ctrl.valueChanged.connect(self._schedule_recompute)
        box.add(self.ws_compactness_ctrl)

        self.ws_line_checkbox = CheckBox(box.content, text="Draw watershed lines")
        self.ws_line_checkbox.setChecked(True)
        self.ws_line_checkbox.stateChanged.connect(self._schedule_recompute)
        box.add(self.ws_line_checkbox)

        return box

    def _build_region_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "7. Region Analysis")
        box.pack(fill="x", pady=4)
        self.min_area_ctrl = ParamControl(
            "Minimum defect area (px)", 1, 500, 5, step=1, decimals=0,
            tooltip="Regions smaller than this (excluding the background region) "
                    "are classified as noise rather than defects.",
            master=box.content,
        )
        self.min_area_ctrl.valueChanged.connect(self._schedule_recompute)
        box.add(self.min_area_ctrl)
        return box

    def _build_overlay_group(self, parent) -> GroupBox:
        box = GroupBox(parent, "8. Overlay")
        box.pack(fill="x", pady=4)
        self.overlay_alpha_ctrl = ParamControl(
            "Overlay alpha", 0.0, 1.0, 0.4, step=0.05, decimals=2,
            master=box.content,
        )
        self.overlay_alpha_ctrl.valueChanged.connect(self._schedule_recompute)
        box.add(self.overlay_alpha_ctrl)

        self.overlay_boundaries_checkbox = CheckBox(box.content, text="Show watershed boundaries")
        self.overlay_boundaries_checkbox.setChecked(True)
        self.overlay_boundaries_checkbox.stateChanged.connect(self._schedule_recompute)
        box.add(self.overlay_boundaries_checkbox)

        return box

    def _build_tabs(self) -> ctk.CTkTabview:
        self.tabs = ctk.CTkTabview(self)

        names = [
            "1. Original", "2. DoG", "3. Gaussian Division", "4. Preprocessing",
            "5. Gradient", "6. Markers", "7. Watershed", "8. Region Analysis",
            "9. Overlay", "Batch Processing",
        ]
        for name in names:
            self.tabs.add(name)

        self.tab_original = ImageTab(self.tabs.tab("1. Original"), "Original Image")
        self.tab_original.pack(fill="both", expand=True)

        self.tab_dog = ImageTab(self.tabs.tab("2. DoG"), "Difference of Gaussian (DoG)")
        self.tab_dog.pack(fill="both", expand=True)

        self.tab_gdiv = ImageTab(self.tabs.tab("3. Gaussian Division"), "Gaussian Division")
        self.tab_gdiv.pack(fill="both", expand=True)

        self.tab_preprocess = ImageTab(self.tabs.tab("4. Preprocessing"), "Preprocessed / Smoothed")
        self.tab_preprocess.pack(fill="both", expand=True)

        self.tab_gradient = ImageTab(self.tabs.tab("5. Gradient"), "Gradient / Topographic Surface")
        self.tab_gradient.pack(fill="both", expand=True)

        self.tab_markers = MarkerTab(self.tabs.tab("6. Markers"))
        self.tab_markers.pack(fill="both", expand=True)

        self.tab_watershed = ImageTab(self.tabs.tab("7. Watershed"), "Watershed Labels", cmap="nipy_spectral")
        self.tab_watershed.pack(fill="both", expand=True)

        self.tab_regions = RegionAnalysisTab(self.tabs.tab("8. Region Analysis"))
        self.tab_regions.pack(fill="both", expand=True)

        self.tab_overlay = ImageTab(self.tabs.tab("9. Overlay"), "Overlay: Detected Defects")
        self.tab_overlay.pack(fill="both", expand=True)

        self.tab_batch = BatchTab(self.tabs.tab("Batch Processing"), get_params_callback=self._collect_params)
        self.tab_batch.pack(fill="both", expand=True)

        return self.tabs

    # -- Event handlers -------------------------------------------------

    def on_load_image(self):
        path = filedialog.askopenfilename(
            title="Load Image",
            filetypes=[
                ("Images", "*.png *.jpg *.jpeg *.bmp *.tif *.tiff"),
                ("All Files", "*.*"),
            ],
        )
        if not path:
            return
        try:
            self.rgb, self.gray = pl.load_image(path)
        except Exception as e:
            messagebox.showerror("Failed to load image", str(e))
            return

        self.tab_original.show_image(self.rgb, info=f"Shape: {self.gray.shape}  |  Source: {path}")
        self.save_btn.configure(state="normal")
        self.statusBar_showMessage(f"Loaded: {path}")
        self._recompute_pipeline()

    def on_save_overlay(self):
        if self._last_result is None:
            return
        path = filedialog.asksaveasfilename(
            title="Save Overlay", defaultextension=".png",
            initialfile="overlay.png", filetypes=[("PNG Image", "*.png")],
        )
        if not path:
            return
        from skimage.io import imsave
        from skimage.util import img_as_ubyte
        imsave(path, img_as_ubyte(np.clip(self._last_result.overlay, 0, 1)))
        self.statusBar_showMessage(f"Overlay saved to {path}")

    def _schedule_recompute(self, *_):
        if self.gray is None:
            return
        if self._recompute_after_id is not None:
            self.after_cancel(self._recompute_after_id)
        self._recompute_after_id = self.after(60, self._recompute_pipeline)

    # -- Pipeline execution ----------------------------------------------

    def _collect_params(self) -> pl.PipelineParams:
        return pl.PipelineParams(
            dog_enabled=self.dog_enabled_checkbox.isChecked(),
            dog_sigma1=self.dog_sigma1_ctrl.value(),
            dog_sigma2=self.dog_sigma2_ctrl.value(),
            gdiv_enabled=self.gdiv_enabled_checkbox.isChecked(),
            gdiv_sigma=self.gdiv_sigma_ctrl.value(),
            gdiv_epsilon=self.gdiv_epsilon_ctrl.value(),
            pre_method=self.pre_method_combo.currentText(),
            gaussian_sigma=self.gaussian_sigma_ctrl.value(),
            median_radius=int(self.median_radius_ctrl.value()),
            bilateral_sigma_color=self.bilateral_sigma_color_ctrl.value(),
            bilateral_sigma_spatial=self.bilateral_sigma_spatial_ctrl.value(),
            grad_method=self.grad_method_combo.currentText(),
            grad_presmooth_sigma=self.grad_presmooth_ctrl.value(),
            grad_morph_radius=int(self.grad_morph_radius_ctrl.value()),
            h_dark=self.h_dark_ctrl.value(),
            h_bright=self.h_bright_ctrl.value(),
            h_background=self.h_background_ctrl.value(),
            marker_dilation=int(self.marker_dilation_ctrl.value()),
            marker_connectivity=self.marker_connectivity_combo.currentIndex() + 1,
            ws_connectivity=self.ws_connectivity_combo.currentIndex() + 1,
            ws_compactness=self.ws_compactness_ctrl.value(),
            ws_watershed_line=self.ws_line_checkbox.isChecked(),
            min_area=int(self.min_area_ctrl.value()),
            overlay_show_boundaries=self.overlay_boundaries_checkbox.isChecked(),
            overlay_alpha=self.overlay_alpha_ctrl.value(),
        )

    def _recompute_pipeline(self):
        self._recompute_after_id = None
        if self.gray is None:
            return
        params = self._collect_params()
        try:
            result = pl.run_pipeline(self.rgb, self.gray, params)
        except Exception as e:
            traceback.print_exc()
            self.statusBar_showMessage(f"Pipeline error: {e}")
            return

        self._last_result = result

        if result.dog_output is not None:
            self.tab_dog.show_image(
                result.dog_output,
                info=f"sigma1={params.dog_sigma1:.2f}, sigma2={params.dog_sigma2:.2f}")
        else:
            self.tab_dog.show_image(None, info="Disabled (bypassed)")

        if result.gdiv_output is not None:
            self.tab_gdiv.show_image(
                result.gdiv_output,
                info=f"sigma={params.gdiv_sigma:.2f}, epsilon={params.gdiv_epsilon:.4f}")
        else:
            self.tab_gdiv.show_image(None, info="Disabled (bypassed)")

        self.tab_preprocess.show_image(
            result.smoothed, info=f"method={params.pre_method}")
        self.tab_gradient.show_image(
            result.gradient, cmap="inferno",
            info=f"method={params.grad_method}, range=[{result.gradient.min():.3f}, {result.gradient.max():.3f}]")
        self.tab_markers.show_markers(
            result.smoothed, result.marker_result,
            info=(f"dark seeds: {result.marker_result.n_dark}   "
                  f"bright seeds: {result.marker_result.n_bright}"))
        n_labels = len(np.unique(result.labels))
        self.tab_watershed.show_image(
            result.labels, cmap="nipy_spectral",
            info=f"{n_labels} watershed regions (including background)")
        self.tab_regions.show_regions(result.region_result)
        n_defects = len(result.region_result.defect_labels)
        self.tab_overlay.show_image(
            result.overlay, info=f"{n_defects} defects highlighted")

        self.statusBar_showMessage(
            f"Pipeline updated — {n_labels} regions, {n_defects} classified as defects."
        )


def main():
    app = MainWindow()
    app.mainloop()


if __name__ == "__main__":
    main()
