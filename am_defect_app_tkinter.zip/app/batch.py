"""
batch.py
========
Batch processing for the AM Defect Detection application.

This module adds folder-at-a-time processing on top of the existing,
unmodified single-image pipeline in `pipeline.py`. It does not alter
any existing pipeline/watershed logic — it simply calls
`pipeline.load_image()` and `pipeline.run_pipeline()` once per image
and writes out the same kinds of outputs the GUI already displays
(preprocessed image, optional DoG/Gaussian-Division outputs, gradient,
markers, watershed labels, defect mask, overlay, and a region-analysis
CSV) into a dedicated output subfolder per input image.

Processing runs on a background `threading.Thread` (`BatchWorker`) so
the Tkinter GUI stays responsive and the run can be cancelled between
images. `BatchWorker` itself has no Tkinter/CustomTkinter dependency —
it invokes the plain callback functions it is given directly from the
worker thread. The GUI layer is responsible for marshalling those
callbacks back onto the main thread (e.g. via `widget.after(0, ...)`)
before touching any widgets.
"""

from __future__ import annotations

import csv
import os
import threading
import traceback
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
from skimage.color import label2rgb
from skimage.io import imsave
from skimage.util import img_as_ubyte

import pipeline as pl

SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}


def list_supported_images(folder: str) -> list[str]:
    """Return sorted absolute paths of all supported images in `folder`."""
    if not folder or not os.path.isdir(folder):
        return []
    files = []
    for name in sorted(os.listdir(folder)):
        ext = os.path.splitext(name)[1].lower()
        if ext in SUPPORTED_EXTENSIONS:
            files.append(os.path.join(folder, name))
    return files


def _save_image(path: str, img: np.ndarray) -> None:
    imsave(path, img_as_ubyte(np.clip(img, 0.0, 1.0)))


def _save_region_csv(path: str, region_result: pl.RegionAnalysisResult) -> None:
    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([
            "label", "role", "area", "mean_intensity", "eccentricity",
            "perimeter", "equivalent_diameter", "solidity",
            "centroid_row", "centroid_col",
        ])
        for r in region_result.table:
            writer.writerow([
                r["label"], r["role"], r["area"],
                f"{r['mean_intensity']:.6f}", f"{r['eccentricity']:.6f}",
                f"{r['perimeter']:.6f}", f"{r['equivalent_diameter']:.6f}",
                f"{r['solidity']:.6f}",
                f"{r['centroid'][0]:.3f}", f"{r['centroid'][1]:.3f}",
            ])


def process_single_image(image_path: str, output_root: str, params: pl.PipelineParams) -> str:
    """
    Run the existing single-image pipeline on `image_path` and save every
    output the application already generates into
    `output_root/<image_name>/`. Reuses pipeline.load_image() and
    pipeline.run_pipeline() unchanged. Returns the created output folder.
    """
    name = os.path.splitext(os.path.basename(image_path))[0]
    out_dir = os.path.join(output_root, name)
    os.makedirs(out_dir, exist_ok=True)

    rgb, gray = pl.load_image(image_path)
    result = pl.run_pipeline(rgb, gray, params)

    _save_image(os.path.join(out_dir, "original.png"), rgb)

    if result.dog_output is not None:
        _save_image(os.path.join(out_dir, "dog_output.png"), result.dog_output)

    if result.gdiv_output is not None:
        _save_image(os.path.join(out_dir, "gaussian_division_output.png"), result.gdiv_output)

    _save_image(os.path.join(out_dir, "preprocessed.png"), result.smoothed)
    _save_image(os.path.join(out_dir, "gradient.png"), result.gradient)

    marker_img = pl.render_marker_image(result.smoothed, result.marker_result)
    imsave(os.path.join(out_dir, "markers.png"), marker_img)

    labels_rgb = label2rgb(result.labels, bg_label=0)
    _save_image(os.path.join(out_dir, "watershed_labels.png"), labels_rgb)

    if result.region_result.defect_mask is not None:
        mask_img = img_as_ubyte(result.region_result.defect_mask.astype(np.float64))
        imsave(os.path.join(out_dir, "defect_mask.png"), mask_img)

    _save_image(os.path.join(out_dir, "overlay.png"), result.overlay)
    _save_region_csv(os.path.join(out_dir, "regions.csv"), result.region_result)

    return out_dir


@dataclass
class BatchError:
    filename: str
    message: str


class BatchWorker:
    """
    Runs process_single_image() over every supported image in a folder,
    off the GUI thread (using a plain `threading.Thread`). Invokes
    plain callback functions so the caller can update a progress bar,
    current-file label, and processed count; continues past per-image
    failures and reports them at the end.

    Callback signatures (mirroring the removed QThread signals):
        on_progress(processed_count: int, total: int)
        on_current_file(filename: str)
        on_image_failed(filename: str, message: str)
        on_finished(total: int, succeeded: int, failed: int)

    IMPORTANT: these callbacks are invoked from the worker thread, not
    the Tkinter main thread. Callers must marshal any GUI updates back
    onto the main thread themselves (e.g. wrapping each callback with
    `root.after(0, ...)`) before touching CTk/Tk widgets.
    """

    def __init__(
        self,
        input_folder: str,
        output_folder: str,
        params: pl.PipelineParams,
        on_progress: Optional[Callable[[int, int], None]] = None,
        on_current_file: Optional[Callable[[str], None]] = None,
        on_image_failed: Optional[Callable[[str, str], None]] = None,
        on_finished: Optional[Callable[[int, int, int], None]] = None,
    ):
        self.input_folder = input_folder
        self.output_folder = output_folder
        self.params = params

        self.on_progress = on_progress
        self.on_current_file = on_current_file
        self.on_image_failed = on_image_failed
        self.on_finished = on_finished

        self._cancel_requested = False
        self._thread: Optional[threading.Thread] = None

    def cancel(self):
        self._cancel_requested = True

    def start(self):
        self._thread = threading.Thread(target=self.run, daemon=True)
        self._thread.start()

    def run(self):
        files = list_supported_images(self.input_folder)
        total = len(files)
        succeeded = 0
        failed = 0

        os.makedirs(self.output_folder, exist_ok=True)

        for i, path in enumerate(files, start=1):
            if self._cancel_requested:
                break
            basename = os.path.basename(path)
            if self.on_current_file:
                self.on_current_file(basename)
            try:
                process_single_image(path, self.output_folder, self.params)
                succeeded += 1
            except Exception as e:
                failed += 1
                if self.on_image_failed:
                    self.on_image_failed(basename, f"{e}\n{traceback.format_exc()}")
            if self.on_progress:
                self.on_progress(i, total)

        if self.on_finished:
            self.on_finished(total, succeeded, failed)
