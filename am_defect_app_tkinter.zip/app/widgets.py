"""
widgets.py
==========
Small reusable CustomTkinter widgets for the AM Defect Detection GUI.

`ParamControl` bundles a CTkSlider and a numeric CTkEntry into one row,
keeping both perfectly in sync and exposing a single `valueChanged`
Signal so the rest of the application does not need to know whether a
given parameter is an int or a float.

`Signal` is a tiny Qt-style observer used throughout this module (and by
gui.py) so widget call sites can keep the familiar
``widget.valueChanged.connect(callback)`` pattern without depending on
PyQt5 in any way.

`CheckBox` and `ComboBox` are thin CustomTkinter wrappers that expose the
same kind of "signal" API as their removed Qt counterparts
(`stateChanged`, `currentTextChanged`, `currentIndexChanged`, ...), and
`GroupBox` reproduces the boxed, titled parameter groups the original
`QGroupBox`-based layout used.
"""

from __future__ import annotations

import tkinter as tk
from typing import Callable, List

import customtkinter as ctk


# ---------------------------------------------------------------------------
# Lightweight Qt-style signal, used everywhere below instead of pyqtSignal.
# ---------------------------------------------------------------------------

class Signal:
    """A minimal observer list mimicking the bits of a Qt signal this app
    uses: `.connect(callback)` and `.emit(*args)`."""

    def __init__(self):
        self._callbacks: List[Callable] = []

    def connect(self, callback: Callable) -> None:
        self._callbacks.append(callback)

    def emit(self, *args) -> None:
        for cb in list(self._callbacks):
            cb(*args)


# ---------------------------------------------------------------------------
# GroupBox — stands in for QGroupBox: a titled, bordered container.
# ---------------------------------------------------------------------------

class GroupBox(ctk.CTkFrame):
    """A bordered frame with a bold title label, used to group related
    parameter controls (the CTk equivalent of a QGroupBox)."""

    def __init__(self, master, title: str, **kwargs):
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("corner_radius", 8)
        super().__init__(master, **kwargs)

        self._title_label = ctk.CTkLabel(
            self, text=title, font=ctk.CTkFont(weight="bold", size=13), anchor="w"
        )
        self._title_label.pack(fill="x", padx=10, pady=(8, 4))

        # `content` is where callers pack/grid their child widgets.
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def add(self, widget, **pack_kwargs) -> None:
        pack_kwargs.setdefault("fill", "x")
        pack_kwargs.setdefault("pady", 2)
        widget.pack(in_=self.content, **pack_kwargs)


# ---------------------------------------------------------------------------
# ParamControl — CTkSlider + CTkEntry kept in sync (replaces QSlider +
# QSpinBox/QDoubleSpinBox pair).
# ---------------------------------------------------------------------------

class ParamControl(ctk.CTkFrame):
    """
    A labeled row containing a slider and a synchronized numeric entry box.

    Exposes `.valueChanged` (a Signal(float)), `.value()`, `.setValue()`
    and `.setEnabled()` -- the same public surface the PyQt5 version had,
    so calling code elsewhere in the app does not need to change.
    """

    def __init__(
        self,
        label: str,
        minimum: float,
        maximum: float,
        value: float,
        step: float = 1.0,
        decimals: int = 0,
        tooltip: str = "",
        master=None,
        **kwargs,
    ):
        super().__init__(master, fg_color="transparent")
        self.valueChanged = Signal()

        self.minimum = float(minimum)
        self.maximum = float(maximum)
        self.decimals = decimals
        self.step = step
        self._syncing = False
        self._enabled = True

        # number_of_steps must be an integer >= 1 for CTkSlider.
        span = max(self.maximum - self.minimum, 1e-9)
        n_steps = max(int(round(span / max(step, 1e-9))), 1)

        self.label = ctk.CTkLabel(self, text=label, anchor="w")
        self.label.grid(row=0, column=0, columnspan=2, sticky="w", padx=2, pady=(4, 0))
        self._tooltip_win = None
        if tooltip:
            self._tooltip_text = tooltip
            # Simple hover tooltip via a bound label; avoids any Qt dependency.
            self.label.bind("<Enter>", self._show_tooltip)
            self.label.bind("<Leave>", self._hide_tooltip)

        self.slider = ctk.CTkSlider(
            self, from_=self.minimum, to=self.maximum,
            number_of_steps=n_steps, command=self._on_slider_changed,
        )
        self.slider.set(float(value))
        self.slider.grid(row=1, column=0, sticky="ew", padx=(2, 8), pady=(0, 4))

        self._entry_var = tk.StringVar()
        self.entry = ctk.CTkEntry(self, width=80, textvariable=self._entry_var)
        self.entry.grid(row=1, column=1, sticky="e", pady=(0, 4))
        self.entry.bind("<Return>", self._on_entry_changed)
        self.entry.bind("<FocusOut>", self._on_entry_changed)

        self.grid_columnconfigure(0, weight=1)
        self.setValue(value)

    # -- tooltip helpers ---------------------------------------------------

    def _show_tooltip(self, _event=None):
        if self._tooltip_win is not None:
            return
        x = self.label.winfo_rootx() + 10
        y = self.label.winfo_rooty() + self.label.winfo_height() + 4
        win = tk.Toplevel(self)
        win.wm_overrideredirect(True)
        win.wm_geometry(f"+{x}+{y}")
        lbl = tk.Label(
            win, text=self._tooltip_text, justify="left",
            background="#2b2b2b", foreground="#f0f0f0",
            relief="solid", borderwidth=1, wraplength=280,
            font=("", 10), padx=6, pady=4,
        )
        lbl.pack()
        self._tooltip_win = win

    def _hide_tooltip(self, _event=None):
        if self._tooltip_win is not None:
            self._tooltip_win.destroy()
            self._tooltip_win = None

    # -- internal sync handlers ---------------------------------------------

    def _format(self, val: float) -> str:
        if self.decimals <= 0:
            return str(int(round(val)))
        return f"{val:.{self.decimals}f}"

    def _on_slider_changed(self, raw_val: float):
        if self._syncing:
            return
        self._syncing = True
        val = raw_val if self.decimals > 0 else round(raw_val)
        val = max(self.minimum, min(self.maximum, val))
        self._entry_var.set(self._format(val))
        self._syncing = False
        self.valueChanged.emit(float(val))

    def _on_entry_changed(self, _event=None):
        if self._syncing:
            return
        try:
            val = float(self._entry_var.get())
        except ValueError:
            val = self.value()
        val = max(self.minimum, min(self.maximum, val))
        if self.decimals <= 0:
            val = round(val)
        self._syncing = True
        self.slider.set(val)
        self._entry_var.set(self._format(val))
        self._syncing = False
        self.valueChanged.emit(float(val))

    # -- public API -----------------------------------------------------

    def value(self) -> float:
        try:
            return float(self._entry_var.get())
        except ValueError:
            return self.slider.get()

    def setValue(self, val: float):
        val = max(self.minimum, min(self.maximum, val))
        if self.decimals <= 0:
            val = round(val)
        self._syncing = True
        self.slider.set(val)
        self._entry_var.set(self._format(val))
        self._syncing = False

    def setEnabled(self, enabled: bool):
        self._enabled = enabled
        state = "normal" if enabled else "disabled"
        self.slider.configure(state=state)
        self.entry.configure(state=state)

    def isEnabled(self) -> bool:
        return self._enabled


# ---------------------------------------------------------------------------
# CheckBox — wraps CTkCheckBox, exposes a Qt-style `.stateChanged` Signal.
# ---------------------------------------------------------------------------

class CheckBox(ctk.CTkCheckBox):
    """CTkCheckBox with a `.stateChanged` Signal(int) and
    `.isChecked()` / `.setChecked()` to match the removed QCheckBox API."""

    def __init__(self, master, text: str = "", **kwargs):
        self.stateChanged = Signal()
        super().__init__(master, text=text, command=self._on_toggled, **kwargs)

    def _on_toggled(self):
        self.stateChanged.emit(int(self.get()))

    def isChecked(self) -> bool:
        return bool(self.get())

    def setChecked(self, checked: bool):
        if checked:
            self.select()
        else:
            self.deselect()
        # Qt's setChecked does not itself emit stateChanged unless the
        # value actually changes; callers that need a recompute call it
        # explicitly, matching the original app's behavior.


# ---------------------------------------------------------------------------
# ComboBox — wraps CTkComboBox, exposes `.currentTextChanged` and
# `.currentIndexChanged` Signals to match the removed QComboBox API.
# ---------------------------------------------------------------------------

class ComboBox(ctk.CTkFrame):
    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent")
        self.currentTextChanged = Signal()
        self.currentIndexChanged = Signal()
        self._values: List[str] = []

        self._combo = ctk.CTkComboBox(self, command=self._on_changed, **kwargs)
        self._combo.pack(fill="x")

    def addItems(self, items: List[str]):
        had_values_before = bool(self._values)
        self._values.extend(items)
        self._combo.configure(values=self._values)
        if self._values and (not had_values_before or self._combo.get() not in self._values):
            self._combo.set(self._values[0])

    def _on_changed(self, value: str):
        self.currentTextChanged.emit(value)
        if value in self._values:
            self.currentIndexChanged.emit(self._values.index(value))

    def currentText(self) -> str:
        return self._combo.get()

    def currentIndex(self) -> int:
        val = self._combo.get()
        return self._values.index(val) if val in self._values else -1

    def setCurrentText(self, text: str):
        self._combo.set(text)

    def setCurrentIndex(self, index: int):
        if 0 <= index < len(self._values):
            self._combo.set(self._values[index])
