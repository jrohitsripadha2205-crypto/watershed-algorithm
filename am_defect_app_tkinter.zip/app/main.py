#!/usr/bin/env python3
"""
main.py
=======
Entry point for the Additive Manufacturing (AM) Defect Detection
application.

Run with:
    python main.py

Requires customtkinter, Pillow, scikit-image, numpy, scipy, and
matplotlib to be installed (see requirements.txt). Tkinter itself
ships with the standard CPython installer on Windows/macOS; on Linux
install it via your distro's package manager (e.g. `apt install
python3-tk`) if `import tkinter` fails.
"""

import sys


def _check_dependencies():
    missing = []
    try:
        import tkinter  # noqa: F401
    except ImportError:
        print("Missing the 'tkinter' standard-library module.")
        print("On Debian/Ubuntu install it with: sudo apt install python3-tk")
        sys.exit(1)

    for module_name, pip_name in [
        ("customtkinter", "customtkinter"),
        ("PIL", "Pillow"),
        ("skimage", "scikit-image"),
        ("numpy", "numpy"),
        ("scipy", "scipy"),
        ("matplotlib", "matplotlib"),
    ]:
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print("Missing required packages:", ", ".join(missing))
        print("Install them with:")
        print(f"    pip install {' '.join(missing)}")
        sys.exit(1)


if __name__ == "__main__":
    _check_dependencies()
    from gui import main
    main()
