"""
pipeline.py
===========
Core image-processing pipeline for the Additive Manufacturing (AM) Defect
Detection application.

IMPORTANT DESIGN CONSTRAINT
----------------------------
No thresholding of any kind (global, adaptive, Otsu, multi-Otsu, Li, Yen,
Triangle, Sauvola, Niblack, or any manual binary cut) is used anywhere in
this module. All region separation is produced exclusively by
`skimage.segmentation.watershed`, driven by:

    * a gradient / topographic elevation surface (skimage.filters), and
    * markers obtained from morphological extrema
      (skimage.morphology.extrema.h_minima / h_maxima), which are
      *topological* (persistence-based) operators, not intensity cut-offs.

Every function below is a pure function: given the same inputs it always
produces the same outputs, and every function returns plain numpy arrays
(plus small metadata dicts) so the GUI layer can display each pipeline
stage independently and re-run only what is necessary.

Pipeline stages
----------------
1. load_image              -> original image (RGB + grayscale float)
2. preprocess               -> denoised / smoothed grayscale image
3. compute_gradient         -> gradient / topographic elevation surface
4. generate_markers         -> labeled marker image (background + defects)
5. run_watershed            -> watershed label image
6. analyze_regions          -> per-region measurements (regionprops based)
7. build_overlay            -> original image with defects highlighted
"""

from __future__ import annotations

import numpy as np
from dataclasses import dataclass, field
from typing import Optional

from skimage import io, color, img_as_float, filters, morphology, measure, segmentation
from skimage.morphology import extrema
from skimage.util import img_as_ubyte


# ---------------------------------------------------------------------------
# 1. Image loading
# ---------------------------------------------------------------------------

def load_image(path: str) -> tuple[np.ndarray, np.ndarray]:
    """
    Load an image from disk.

    Returns
    -------
    rgb : (H, W, 3) float array in [0, 1]
        RGB version of the image, used for display and overlay.
    gray : (H, W) float array in [0, 1]
        Grayscale version of the image, used for all processing.
    """
    raw = io.imread(path)

    # Normalize to float [0, 1] regardless of source dtype.
    raw = img_as_float(raw)

    if raw.ndim == 2:
        gray = raw
        rgb = color.gray2rgb(raw)
    elif raw.ndim == 3:
        if raw.shape[2] == 4:
            raw = raw[..., :3]  # drop alpha
        if raw.shape[2] == 1:
            gray = raw[..., 0]
            rgb = color.gray2rgb(gray)
        else:
            rgb = raw
            gray = color.rgb2gray(raw)
    else:
        raise ValueError(f"Unsupported image shape: {raw.shape}")

    return rgb.astype(np.float64), gray.astype(np.float64)


# ---------------------------------------------------------------------------
# 1.5 Optional Gaussian-based preprocessing (DoG / Gaussian Division)
# ---------------------------------------------------------------------------
#
# These two modules are purely optional, independent, pre-pipeline
# enhancement steps. When enabled they replace the working grayscale
# image that is subsequently handed to the existing (unmodified)
# preprocess() / compute_gradient() / generate_markers() / run_watershed()
# stages below. Neither module performs any thresholding.
#
# Processing order (each stage optional/bypassable):
#   Input -> DoG (optional) -> Gaussian Division (optional) -> existing
#   Watershed pipeline (preprocess -> gradient -> markers -> watershed ->
#   regions -> overlay)

def difference_of_gaussian(
    gray: np.ndarray,
    sigma1: float = 1.0,
    sigma2: float = 2.0,
) -> np.ndarray:
    """
    Difference of Gaussian (DoG) band-pass enhancement.

        DoG = Gaussian(I, sigma1) - Gaussian(I, sigma2)

    The result is rescaled to [0, 1] so it can be fed into the existing
    preprocess/gradient/marker stages, which expect a normalized
    intensity surface.
    """
    img = gray.astype(np.float64)
    g1 = filters.gaussian(img, sigma=max(sigma1, 1e-6))
    g2 = filters.gaussian(img, sigma=max(sigma2, 1e-6))
    dog = g1 - g2

    d_min, d_max = dog.min(), dog.max()
    if d_max > d_min:
        dog = (dog - d_min) / (d_max - d_min)
    else:
        dog = np.zeros_like(dog)
    return dog


def gaussian_division(
    gray: np.ndarray,
    sigma: float = 5.0,
    epsilon: float = 1e-4,
) -> np.ndarray:
    """
    Gaussian Division: flattens uneven illumination by dividing the image
    by a heavily-blurred version of itself.

        Output = I / (Gaussian(I, sigma) + epsilon)

    The result is rescaled to [0, 1] so it can be fed into the existing
    preprocess/gradient/marker stages, which expect a normalized
    intensity surface.
    """
    img = gray.astype(np.float64)
    blurred = filters.gaussian(img, sigma=max(sigma, 1e-6))
    out = img / (blurred + max(epsilon, 1e-12))

    o_min, o_max = out.min(), out.max()
    if o_max > o_min:
        out = (out - o_min) / (o_max - o_min)
    else:
        out = np.zeros_like(out)
    return out


def render_marker_image(smoothed: np.ndarray, marker_result: "MarkerResult") -> np.ndarray:
    """
    Pure-numpy visualization of watershed seed markers on top of the
    smoothed grayscale image (dark-defect seeds in blue, bright-defect
    seeds in red, background seeds in green). Used by batch processing
    to save a marker image without requiring a GUI/matplotlib canvas;
    reused wherever a static marker preview is needed.
    """
    base = np.clip(smoothed.astype(np.float64), 0, 1)
    rgb = np.stack([base, base, base], axis=-1)
    out = (rgb * 255).astype(np.uint8)
    out[marker_result.background_mask] = np.array([0, 200, 0], dtype=np.uint8)
    out[marker_result.dark_mask] = np.array([30, 144, 255], dtype=np.uint8)
    out[marker_result.bright_mask] = np.array([220, 0, 0], dtype=np.uint8)
    return out


# ---------------------------------------------------------------------------
# 2. Preprocessing (denoising / smoothing only — no thresholding)
# ---------------------------------------------------------------------------

def preprocess(
    gray: np.ndarray,
    method: str = "gaussian",
    gaussian_sigma: float = 1.0,
    median_radius: int = 2,
    bilateral_sigma_color: float = 0.05,
    bilateral_sigma_spatial: float = 5.0,
) -> np.ndarray:
    """
    Denoise / smooth the grayscale image prior to gradient computation.

    method: 'none' | 'gaussian' | 'median' | 'bilateral'
    """
    img = gray.astype(np.float64)

    if method == "none":
        return img.copy()

    if method == "gaussian":
        return filters.gaussian(img, sigma=max(gaussian_sigma, 1e-6))

    if method == "median":
        radius = max(int(round(median_radius)), 1)
        return filters.median(img, morphology.disk(radius))

    if method == "bilateral":
        from skimage.restoration import denoise_bilateral
        return denoise_bilateral(
            img,
            sigma_color=max(bilateral_sigma_color, 1e-6),
            sigma_spatial=max(bilateral_sigma_spatial, 1e-6),
            channel_axis=None,
        )

    raise ValueError(f"Unknown preprocessing method: {method}")


# ---------------------------------------------------------------------------
# 3. Gradient / topographic elevation surface
# ---------------------------------------------------------------------------

def compute_gradient(
    smoothed: np.ndarray,
    method: str = "sobel",
    presmooth_sigma: float = 0.0,
    morph_radius: int = 1,
) -> np.ndarray:
    """
    Build the elevation ("topographic") surface that watershed will flood.

    method: 'sobel' | 'scharr' | 'prewitt' | 'morphological'
    presmooth_sigma: optional extra Gaussian smoothing of the gradient
        surface itself, useful to merge noisy micro-basins.
    morph_radius: structuring-element radius for the morphological
        gradient (dilation - erosion), only used when method='morphological'.
    """
    img = smoothed.astype(np.float64)

    if method == "sobel":
        grad = filters.sobel(img)
    elif method == "scharr":
        grad = filters.scharr(img)
    elif method == "prewitt":
        grad = filters.prewitt(img)
    elif method == "morphological":
        radius = max(int(round(morph_radius)), 1)
        selem = morphology.disk(radius)
        grad = morphology.dilation(img, selem) - morphology.erosion(img, selem)
    else:
        raise ValueError(f"Unknown gradient method: {method}")

    if presmooth_sigma > 0:
        grad = filters.gaussian(grad, sigma=presmooth_sigma)

    # Normalize for consistent display / consistent compactness scaling.
    g_min, g_max = grad.min(), grad.max()
    if g_max > g_min:
        grad = (grad - g_min) / (g_max - g_min)
    return grad


# ---------------------------------------------------------------------------
# 4. Marker generation (extrema-based — NOT threshold-based)
# ---------------------------------------------------------------------------

@dataclass
class MarkerResult:
    markers: np.ndarray            # labeled marker image (int)
    dark_mask: np.ndarray           # boolean mask of dark-defect marker seeds
    bright_mask: np.ndarray         # boolean mask of bright-defect marker seeds
    background_mask: np.ndarray     # boolean mask of background marker seed
    n_dark: int = 0
    n_bright: int = 0


def generate_markers(
    smoothed: np.ndarray,
    gradient: np.ndarray,
    h_dark: float = 0.03,
    h_bright: float = 0.03,
    h_background: float = 0.05,
    marker_dilation: int = 0,
    connectivity: int = 2,
) -> MarkerResult:
    """
    Build watershed seed markers purely from morphological extrema
    (h-minima / h-maxima persistence transforms). No intensity threshold
    is applied anywhere in this function.

    - Dark defects (pits, voids, lack-of-fusion) show up as local
      *minima* of the intensity surface -> h_minima(smoothed, h_dark).
    - Bright defects (spatter, over-melt highlights) show up as local
      *maxima* of the intensity surface -> h_maxima(smoothed, h_bright).
    - Background seeds come from the flattest (lowest-persistence-minima)
      regions of the *gradient* surface: h_minima(gradient, h_background).
      This identifies large, texture-free plateaus that are extremely
      unlikely to belong to a defect, without ever comparing a pixel to
      a fixed intensity cut-off.

    Parameters
    ----------
    marker_dilation : int
        Optional binary dilation radius applied to every seed mask, to
        make small marker points more robust seeds for watershed.
    connectivity : int
        1 (4-connected) or 2 (8-connected) used both for extrema
        computation and for labeling connected marker components.
    """
    smoothed = smoothed.astype(np.float64)
    gradient = gradient.astype(np.float64)

    # --- Defect seeds: intensity extrema -----------------------------
    dark_mask = extrema.h_minima(smoothed, h=max(h_dark, 1e-6))
    bright_mask = extrema.h_maxima(smoothed, h=max(h_bright, 1e-6))

    # --- Background seed: flat (low persistence-minima) gradient -----
    background_mask = extrema.h_minima(gradient, h=max(h_background, 1e-6))
    # A pixel cannot simultaneously be a defect seed and a background seed.
    background_mask = background_mask & ~dark_mask & ~bright_mask

    if marker_dilation > 0:
        selem = morphology.disk(int(round(marker_dilation)))
        dark_mask = morphology.dilation(dark_mask, selem)
        bright_mask = morphology.dilation(bright_mask, selem)
        background_mask = morphology.dilation(background_mask, selem)
        # Re-enforce exclusivity after dilation.
        background_mask = background_mask & ~dark_mask & ~bright_mask

    # --- Label each seed family separately, then merge ---------------
    dark_labels = measure.label(dark_mask, connectivity=connectivity)
    bright_labels = measure.label(bright_mask, connectivity=connectivity)
    bg_labels = measure.label(background_mask, connectivity=connectivity)

    n_dark = int(dark_labels.max())
    n_bright = int(bright_labels.max())
    n_bg = int(bg_labels.max())

    markers = np.zeros(smoothed.shape, dtype=np.int32)

    # Background gets the lowest label id (1..n_bg).
    markers[bg_labels > 0] = bg_labels[bg_labels > 0]

    # Dark defects: offset after background labels.
    offset = n_bg
    dark_offset = np.where(dark_labels > 0, dark_labels + offset, 0)
    markers[dark_labels > 0] = dark_offset[dark_labels > 0]

    # Bright defects: offset after dark labels.
    offset += n_dark
    bright_offset = np.where(bright_labels > 0, bright_labels + offset, 0)
    markers[bright_labels > 0] = bright_offset[bright_labels > 0]

    # Safety net: if no background seed was found at all (rare, on very
    # busy images), fall back to a single marker at the image border,
    # which is a purely geometric (not intensity-based) choice.
    if n_bg == 0:
        border = np.zeros(smoothed.shape, dtype=bool)
        border[0, :] = border[-1, :] = True
        border[:, 0] = border[:, -1] = True
        border &= ~(dark_mask | bright_mask)
        if border.any():
            new_label = markers.max() + 1
            markers[border] = new_label
            background_mask = border

    return MarkerResult(
        markers=markers,
        dark_mask=dark_mask,
        bright_mask=bright_mask,
        background_mask=background_mask,
        n_dark=n_dark,
        n_bright=n_bright,
    )


# ---------------------------------------------------------------------------
# 5. Watershed segmentation
# ---------------------------------------------------------------------------

def run_watershed(
    gradient: np.ndarray,
    markers: np.ndarray,
    connectivity: int = 2,
    compactness: float = 0.0,
    watershed_line: bool = True,
) -> np.ndarray:
    """
    Run skimage.segmentation.watershed on the gradient surface, seeded by
    the marker image. This is the ONLY segmentation step in the whole
    application.
    """
    conn_footprint = (
        np.ones((3, 3), dtype=bool) if connectivity == 2 else
        np.array([[0, 1, 0], [1, 1, 1], [0, 1, 0]], dtype=bool)
    )

    labels = segmentation.watershed(
        gradient,
        markers=markers,
        connectivity=conn_footprint,
        compactness=max(compactness, 0.0),
        watershed_line=watershed_line,
    )
    return labels


# ---------------------------------------------------------------------------
# 6. Region analysis
# ---------------------------------------------------------------------------

@dataclass
class RegionAnalysisResult:
    table: list = field(default_factory=list)     # list of dict rows
    background_label: Optional[int] = None
    defect_labels: list = field(default_factory=list)
    defect_mask: Optional[np.ndarray] = None


def analyze_regions(
    labels: np.ndarray,
    gray: np.ndarray,
    min_area: int = 5,
    background_seed_labels: Optional[set] = None,
) -> RegionAnalysisResult:
    """
    Compute per-region measurements with skimage.measure.regionprops and
    classify regions as background vs. defect.

    Classification rule (no intensity threshold involved):
      * The region carrying the marker id(s) generated as *background
        seeds* in `generate_markers` (passed in via
        `background_seed_labels`) is treated as background.
      * If that information is unavailable, the single largest-area
        region is treated as background (purely a size/topology
        criterion, not an intensity cut-off).
      * Regions with area < min_area are treated as noise and dropped
        from the defect list (a region-size filter, not a pixel
        intensity threshold).
    """
    props = measure.regionprops(labels, intensity_image=gray)

    if not props:
        return RegionAnalysisResult()

    # Decide the background label.
    background_label = None
    if background_seed_labels:
        candidates = [p.label for p in props if p.label in background_seed_labels]
        if candidates:
            # pick the largest background-seeded region as "the" background
            background_label = max(
                candidates, key=lambda lbl: next(p.area for p in props if p.label == lbl)
            )
    if background_label is None:
        background_label = max(props, key=lambda p: p.area).label

    table = []
    defect_labels = []
    defect_mask = np.zeros(labels.shape, dtype=bool)

    for p in props:
        is_background = p.label == background_label
        is_noise = (not is_background) and (p.area < min_area)
        mean_intensity = float(
            p.intensity_mean if hasattr(p, "intensity_mean") else p.mean_intensity
        )
        equiv_diam = float(
            p.equivalent_diameter_area if hasattr(p, "equivalent_diameter_area")
            else p.equivalent_diameter
        )
        row = {
            "label": int(p.label),
            "area": int(p.area),
            "mean_intensity": mean_intensity,
            "eccentricity": float(p.eccentricity) if p.area > 1 else 0.0,
            "perimeter": float(p.perimeter),
            "equivalent_diameter": equiv_diam,
            "solidity": float(p.solidity) if p.area > 2 else 1.0,
            "centroid": tuple(float(c) for c in p.centroid),
            "role": "background" if is_background else ("noise" if is_noise else "defect"),
        }
        table.append(row)
        if row["role"] == "defect":
            defect_labels.append(p.label)
            defect_mask |= (labels == p.label)

    return RegionAnalysisResult(
        table=table,
        background_label=background_label,
        defect_labels=defect_labels,
        defect_mask=defect_mask,
    )


# ---------------------------------------------------------------------------
# 7. Overlay
# ---------------------------------------------------------------------------

def build_overlay(
    rgb: np.ndarray,
    labels: np.ndarray,
    defect_mask: np.ndarray,
    show_boundaries: bool = True,
    alpha: float = 0.4,
) -> np.ndarray:
    """
    Produce an RGB image with defects highlighted on top of the original
    image: colored region fill (via label2rgb) for defect regions plus
    optional watershed boundary lines.
    """
    from skimage.segmentation import mark_boundaries
    from skimage.color import label2rgb

    base = rgb.astype(np.float64)
    if base.max() > 1.0:
        base = base / 255.0

    defect_labels_img = np.where(defect_mask, labels, 0)

    overlay = label2rgb(
        defect_labels_img,
        image=base,
        bg_label=0,
        alpha=alpha,
        colors=["red", "yellow", "cyan", "magenta", "lime", "orange"],
        kind="overlay",
    )

    if show_boundaries:
        overlay = mark_boundaries(overlay, labels, color=(0, 1, 1), mode="thin")

    return np.clip(overlay, 0, 1)


# ---------------------------------------------------------------------------
# End-to-end convenience runner
# ---------------------------------------------------------------------------

@dataclass
class PipelineParams:
    # optional pre-pipeline Gaussian enhancement (DoG)
    dog_enabled: bool = False
    dog_sigma1: float = 1.0
    dog_sigma2: float = 2.0
    # optional pre-pipeline Gaussian enhancement (Gaussian Division)
    gdiv_enabled: bool = False
    gdiv_sigma: float = 5.0
    gdiv_epsilon: float = 1e-4
    # preprocessing
    pre_method: str = "gaussian"
    gaussian_sigma: float = 1.0
    median_radius: int = 2
    bilateral_sigma_color: float = 0.05
    bilateral_sigma_spatial: float = 5.0
    # gradient
    grad_method: str = "sobel"
    grad_presmooth_sigma: float = 0.0
    grad_morph_radius: int = 1
    # markers
    h_dark: float = 0.03
    h_bright: float = 0.03
    h_background: float = 0.05
    marker_dilation: int = 0
    marker_connectivity: int = 2
    # watershed
    ws_connectivity: int = 2
    ws_compactness: float = 0.0
    ws_watershed_line: bool = True
    # region analysis
    min_area: int = 5
    # overlay
    overlay_show_boundaries: bool = True
    overlay_alpha: float = 0.4


@dataclass
class PipelineResult:
    rgb: np.ndarray
    gray: np.ndarray
    smoothed: np.ndarray
    gradient: np.ndarray
    marker_result: MarkerResult
    labels: np.ndarray
    region_result: RegionAnalysisResult
    overlay: np.ndarray
    dog_output: Optional[np.ndarray] = None
    gdiv_output: Optional[np.ndarray] = None


def run_pipeline(rgb: np.ndarray, gray: np.ndarray, params: PipelineParams) -> PipelineResult:
    """Run every stage of the pipeline in sequence and return all outputs.

    Optional pre-pipeline stage: DoG (optional) -> Gaussian Division
    (optional). Each is fully bypassed when disabled, in which case
    `working_gray` stays identical to the original `gray` and the
    existing (unmodified) watershed pipeline behaves exactly as before.
    """
    working_gray = gray
    dog_output: Optional[np.ndarray] = None
    gdiv_output: Optional[np.ndarray] = None

    if params.dog_enabled:
        working_gray = difference_of_gaussian(
            working_gray, sigma1=params.dog_sigma1, sigma2=params.dog_sigma2
        )
        dog_output = working_gray

    if params.gdiv_enabled:
        working_gray = gaussian_division(
            working_gray, sigma=params.gdiv_sigma, epsilon=params.gdiv_epsilon
        )
        gdiv_output = working_gray

    smoothed = preprocess(
        working_gray,
        method=params.pre_method,
        gaussian_sigma=params.gaussian_sigma,
        median_radius=params.median_radius,
        bilateral_sigma_color=params.bilateral_sigma_color,
        bilateral_sigma_spatial=params.bilateral_sigma_spatial,
    )

    gradient = compute_gradient(
        smoothed,
        method=params.grad_method,
        presmooth_sigma=params.grad_presmooth_sigma,
        morph_radius=params.grad_morph_radius,
    )

    marker_result = generate_markers(
        smoothed,
        gradient,
        h_dark=params.h_dark,
        h_bright=params.h_bright,
        h_background=params.h_background,
        marker_dilation=params.marker_dilation,
        connectivity=params.marker_connectivity,
    )

    labels = run_watershed(
        gradient,
        marker_result.markers,
        connectivity=params.ws_connectivity,
        compactness=params.ws_compactness,
        watershed_line=params.ws_watershed_line,
    )

    background_seed_labels = set(np.unique(marker_result.markers[marker_result.background_mask]))
    region_result = analyze_regions(
        labels,
        working_gray,
        min_area=params.min_area,
        background_seed_labels=background_seed_labels,
    )

    overlay = build_overlay(
        rgb,
        labels,
        region_result.defect_mask if region_result.defect_mask is not None
        else np.zeros(gray.shape, dtype=bool),
        show_boundaries=params.overlay_show_boundaries,
        alpha=params.overlay_alpha,
    )

    return PipelineResult(
        rgb=rgb,
        gray=gray,
        smoothed=smoothed,
        gradient=gradient,
        marker_result=marker_result,
        labels=labels,
        region_result=region_result,
        overlay=overlay,
        dog_output=dog_output,
        gdiv_output=gdiv_output,
    )
