"""Utils package: shared helpers, configuration, and constants."""
