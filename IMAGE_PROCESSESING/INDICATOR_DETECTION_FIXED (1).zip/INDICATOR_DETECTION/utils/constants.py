"""
Application-wide constants.

These values were originally hardcoded inline inside
``ImageAnalyzerApp.__init__`` in the single-file version of this
application. They are reproduced here **unchanged** (same literal
values) and simply referenced from ``app.py`` instead of being
duplicated inline, per the "centralize configuration values" goal of
the refactor. No value has been altered.
"""

# ── Colour palette (professional dark-steel theme) ─────────────────────────
COLOR_BG = '#1e2328'   # near-black charcoal
COLOR_PANEL = '#252b33'   # dark steel panel
COLOR_ACCENT = '#2e3a4a'   # muted slate-blue accent
COLOR_HIGHLIGHT = '#2d7dd2'   # professional azure blue
COLOR_FG = '#dde3ea'   # soft white text
COLOR_FG2 = '#7f8c9a'   # muted grey-blue subtext
COLOR_BTN_BG = '#2e3a4a'   # slate button
COLOR_BTN_ACT = '#1a5fa8'   # darker azure on hover
COLOR_ENTRY_BG = '#181d22'   # deep input background

# ── Window sizing ───────────────────────────────────────────────────────────
MAIN_WINDOW_GEOMETRY = "1400x900"
HEADER_HEIGHT = 54
FOOTER_HEIGHT = 28

# ── Header / footer text ────────────────────────────────────────────────────
APP_HEADER_TITLE = 'ADDITIVE MANUFACTURING DEFECT DETECTION'
APP_FOOTER_TEXT = 'Designed and Developed by RCI-DAIV'

# ── Navigation tab keys/labels (used to build the nav pill buttons) ────────
NAV_TABS = [
    ('single', 'Single Image'),
    ('batch', 'Batch Processing & 3D Visualization'),
]

# ── Default 14-step pipeline parameters ─────────────────────────────────────
# Single source of truth for the per-step parameter defaults, used by both
# the Single Image tab (ui/tabs.py) and the Batch tab (processing/batch.py)
# so the two can never drift apart again. Steps 0/1 have no tunable
# parameters (original image / ROI mask) so they have no entry here.
#
# IMPORTANT (regression fix): `step_7_markers.enabled` must be True to match
# the original pipeline's equivalent step (step_5_markers.enabled: True in
# the 12-step version). Leaving it False makes every masked pixel count as
# foreground, producing one oversized blob that gets filtered out entirely
# at Step 13 (min_area/max_area), so nearly every image is misclassified as
# Non-Indicator.
DEFAULT_PIPELINE_PARAMS = {
    'step_2_rotate_flip':   {'enabled': True, 'rotate': 0, 'flip_h': False, 'flip_v': False},
    'step_3_grayscale':     {'enabled': True},
    'step_4_sobel':         {'enabled': False},
    'step_5_topography':    {'enabled': True, 'use_gradient': False, 'peak_threshold_ratio': 0.5,
                              'gaussian_division_enabled': True, 'gaussian_sigma': 50.0},
    'step_6_topo_watershed': {'enabled': True, 'min_distance': 5, 'compactness': 0.0, 'connectivity': 1},
    'step_7_markers':       {'enabled': True, 'low_threshold': 90, 'high_threshold': 220},
    'step_8_watershed':     {'enabled': False},
    'step_9_morph_close':   {'enabled': False, 'iterations': 1},
    'step_10_morph_open':   {'enabled': False, 'iterations': 1},
    'step_11_fillholes':    {'enabled': False},
    'step_12_labeling':     {'enabled': True, 'min_size': 50},
    'step_13_final':        {'min_area': 50, 'max_area': 10000},
    'step_14_perspective':  {'enabled': True},
}
