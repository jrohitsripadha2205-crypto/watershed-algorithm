"""Processing package: image-processing pipelines (single image, batch, slicing, reports)."""
