"""
Main Application class.

Composes all the UI/processing mixins together and owns the top-level
window state (header, footer, nav, tab frames, login state). The
``__init__`` body and the navigation/login-state methods below are
relocated verbatim from ``ImageAnalyzerApp`` in the original
single-file application -- the only changes are: (1) the hardcoded
color / geometry / label literals now come from ``utils.constants``
(same values, just centralised, see utils/constants.py), and (2) the
class body itself now also lists the mixins it is composed from.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

from .utils import constants
from .utils.fonts import _resolve_font_family, _resolve_font_mono

from .ui.widgets import WidgetsMixin
from .ui.dialogs import DialogsMixin
from .ui.tabs import TabsMixin
from .processing.slicer import SlicerMixin
from .processing.single import SingleImageMixin
from .processing.batch import BatchMixin
from .processing.reports import ReportsMixin


class Application(
    WidgetsMixin,
    DialogsMixin,
    TabsMixin,
    SlicerMixin,
    SingleImageMixin,
    BatchMixin,
    ReportsMixin,
):
    """
    The main application window/controller.

    This is exactly ``ImageAnalyzerApp`` from the original single-file
    script, split via the mixin pattern: every method that used to live
    directly on ``ImageAnalyzerApp`` now lives on one of the mixins
    above (grouped by responsibility -- see each mixin module's
    docstring), but because they are combined here via multiple
    inheritance they all still share the same ``self`` they always
    did. No method body, attribute name, or call path was changed by
    this split.
    """

    def __init__(self, root):
        self.root = root
        #self.root.title("Indicator Detection")
        self.root.title("")
        self.root.geometry(constants.MAIN_WINDOW_GEOMETRY)
        self.root.configure(bg=constants.COLOR_BG)

        # ── MODIFIED (Change 4   Application Font): resolve a modern,
        # professional font family once, then reference self.FONT /
        # self.FONT_MONO everywhere a font tuple is needed below instead of
        # hardcoding family names. ─────────────────────────────────────────
        self.FONT = _resolve_font_family()
        self.FONT_MONO = _resolve_font_mono()
        # ── END MODIFIED (Change 4) ─────────────────────────────────────


        # ── Colour palette  (professional dark-steel theme) ─────────────
        # Values now centralised in utils/constants.py -- identical values,
        # just no longer duplicated inline.
        self.BG        = constants.COLOR_BG
        self.PANEL     = constants.COLOR_PANEL
        self.ACCENT    = constants.COLOR_ACCENT
        self.HIGHLIGHT = constants.COLOR_HIGHLIGHT
        self.FG        = constants.COLOR_FG
        self.FG2       = constants.COLOR_FG2
        self.BTN_BG    = constants.COLOR_BTN_BG
        self.BTN_ACT   = constants.COLOR_BTN_ACT
        self.ENTRY_BG  = constants.COLOR_ENTRY_BG

        # ── ttk style ───────────────────────────────────────────────────
        style = ttk.Style()
        style.theme_use('clam')

        style.configure('.',
                        background=self.BG,
                        foreground=self.FG,
                        fieldbackground=self.ENTRY_BG,
                        font=(self.FONT, 10))

        style.configure('TFrame',       background=self.BG)
        style.configure('TLabel',       background=self.BG,  foreground=self.FG)
        style.configure('TLabelframe',  background=self.PANEL, foreground=self.FG)
        style.configure('TLabelframe.Label', background=self.PANEL, foreground=self.HIGHLIGHT,
                        font=('self.FONT', 10, 'bold'))

        style.configure('TButton',
                        background=self.BTN_BG, foreground=self.FG,
                        font=('self.FONT', 10, 'bold'), relief='flat',
                        borderwidth=0, padding=(10, 6))
        style.map('TButton',
                  background=[('active', self.BTN_ACT), ('disabled', '#2a3040')],
                  foreground=[('disabled', '#5a6472')])

        style.configure('Nav.TButton',
                        background=self.PANEL, foreground=self.FG2,
                        font=('self.FONT', 11, 'bold'), relief='flat', padding=(16, 8))
        style.map('Nav.TButton',
                  background=[('active', self.HIGHLIGHT)],
                  foreground=[('active', '#ffffff')])

        style.configure('Active.Nav.TButton',
                        background=self.HIGHLIGHT, foreground='#ffffff',
                        font=('self.FONT', 11, 'bold'), relief='flat', padding=(16, 8))

        style.configure('Danger.TButton',
                        background='#1e3a2f', foreground='#5dbf8e',
                        font=('self.FONT', 10, 'bold'), relief='flat', padding=(10, 6))
        style.map('Danger.TButton', background=[('active', '#14532d')])

        style.configure('TEntry',
                        fieldbackground=self.ENTRY_BG, foreground=self.FG,
                        insertcolor=self.FG, relief='flat')
        style.configure('TScrollbar', background=self.ACCENT,
                        troughcolor=self.BG, bordercolor=self.BG)
        style.configure('Horizontal.TProgressbar',
                        troughcolor=self.PANEL, background=self.HIGHLIGHT,
                        bordercolor=self.BG)
        style.configure('TCheckbutton',
                        background=self.PANEL, foreground=self.FG)
        style.map('TCheckbutton', background=[('active', self.PANEL)])
        style.configure('TScale', background=self.PANEL, troughcolor=self.ACCENT)
        style.configure('TSpinbox',
                        fieldbackground=self.ENTRY_BG, foreground=self.FG,
                        background=self.ACCENT, arrowcolor=self.FG)
        style.configure('TSeparator', background=self.ACCENT)

        # ── Top header bar ──────────────────────────────────────────────
        header = tk.Frame(root, bg=self.PANEL, height=constants.HEADER_HEIGHT)
        header.pack(side='top', fill='x')
        header.pack_propagate(False)

        # App title (centered)
        tk.Label(header, text=constants.APP_HEADER_TITLE,
                 bg=self.PANEL, fg=self.HIGHLIGHT,
                 font=('self.FONT', 16, 'bold')).place(relx=0.5, rely=0.5, anchor='center')

        # Logout button (right-aligned) – hidden until login
        self._logout_btn = tk.Button(header, text='Logout',
                               bg='#1e3a2f', fg='#5dbf8e', relief='flat',
                               font=('self.FONT', 10, 'bold'), padx=14, pady=4,
                               activebackground='#14532d', activeforeground='#ffffff',
                               cursor='hand2',
                               command=self._logout)
        # Do NOT pack yet   shown after login

        # Navigation tabs (horizontal pill buttons)
        nav_frame = tk.Frame(header, bg=self.PANEL)
        nav_frame.pack(side='left', padx=30)

        self._tab_buttons = {}
        self._current_tab = None

        tabs = constants.NAV_TABS
        for key, label in tabs:
            btn = tk.Button(nav_frame, text=label,
                            bg=self.PANEL, fg=self.FG2, relief='flat',
                            font=('self.FONT', 11, 'bold'), padx=16, pady=6,
                            activebackground=self.HIGHLIGHT, activeforeground='#ffffff',
                            cursor='hand2',
                            command=lambda k=key: self._switch_tab(k))
            self._tab_buttons[key] = btn
            # Note: neither tab button is packed/shown in the header any
            # more   the "batch" view is shown by default and reachable
            # programmatically via self._switch_tab(), and the "single"
            # view remains reachable through its existing internal
            # triggers (e.g. after login). This preserves all existing
            # tab-switching functionality without displaying the old
            # nav pill buttons (including the removed banner-style
            # "Batch Processing & 3D Visualization" button) in the UI.

        # Hide Single Image tab until login
        self._tab_buttons['single'].pack_forget()

        # ── Content area ────────────────────────────────────────────────
        self.content = tk.Frame(root, bg=self.BG)
        self.content.pack(fill='both', expand=True)

        self.tab_frames = {}
        for key, _ in tabs:
            f = tk.Frame(self.content, bg=self.BG)
            self.tab_frames[key] = f

        # ── Footer ──────────────────────────────────────────────────────
        footer = tk.Frame(root, bg=self.PANEL, height=constants.FOOTER_HEIGHT)
        footer.pack(side='bottom', fill='x')
        footer.pack_propagate(False)
        tk.Label(footer, text=constants.APP_FOOTER_TEXT,
                 bg=self.PANEL, fg=self.FG2, font=('self.FONT', 9)).pack(expand=True)

        # ── Wire up legacy tab references ───────────────────────────────
        # Tab 1 = single image  (used by init_tab1 / watershed logic)
        self.tab2 = self.tab_frames['single']
        # Tab 3 = batch + 3D viz + reports (merged)
        self.tab3 = self.tab_frames['batch']

        # ── Initialise tab contents ─────────────────────────────────────
        self.init_tab1()          # ROI Selection     popup window
        self.init_tab2()          # Watershed         'single' frame
        self._init_tab_batch_3d() # Merged Batch + 3D Viz + Reports    'batch' frame

        # Show default tab
        self._switch_tab('batch')

        # ── Login state & Ctrl+A+B shortcut ────────────────────────────
        self._logged_in = False
        self._keys_down = set()
        self.root.bind('<KeyPress>',   self._track_key_down)
        self.root.bind('<KeyRelease>', self._track_key_up)

    def _switch_tab(self, key):
        # Single Image tab requires login
        if key == 'single' and not self._logged_in:
            self._open_login_popup()
            return
        for k, f in self.tab_frames.items():
            f.pack_forget()
        self.tab_frames[key].pack(fill='both', expand=True)
        for k, btn in self._tab_buttons.items():
            if k == key:
                btn.configure(bg=self.HIGHLIGHT, fg='#ffffff')
            else:
                btn.configure(bg=self.PANEL, fg=self.FG2)
        self._current_tab = key

    def _logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self._logged_in = False
            # Hide Single Image tab button and logout button
            self._tab_buttons['single'].pack_forget()
            self._logout_btn.pack_forget()
            # Switch back to batch tab
            self._switch_tab('batch')

    def _track_key_down(self, event):
        self._keys_down.add(event.keysym.lower())
        ctrl_held = ('control_l' in self._keys_down or
                     'control_r' in self._keys_down or
                     'control'   in self._keys_down)
        if ctrl_held and 'a' in self._keys_down and 'b' in self._keys_down:
            self._keys_down.clear()          # prevent repeated triggers
            self._open_login_popup()

    def _track_key_up(self, event):
        self._keys_down.discard(event.keysym.lower())

    def _switch_tab_direct(self, key):
        """Switch tab without the login gate (used after successful login)."""
        for k, f in self.tab_frames.items():
            f.pack_forget()
        self.tab_frames[key].pack(fill='both', expand=True)
        for k, btn in self._tab_buttons.items():
            btn.configure(bg=self.HIGHLIGHT if k == key else self.PANEL,
                          fg='#ffffff' if k == key else self.FG2)
        self._current_tab = key

